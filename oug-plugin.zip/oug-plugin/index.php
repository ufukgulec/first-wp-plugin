<?php
// Silence is golden .